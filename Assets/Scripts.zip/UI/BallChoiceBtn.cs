using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallChoiceBtn : MonoBehaviour
{
    [SerializeField]
    private BallChoiceUI ballUI;
    [SerializeField]
    private PitchType pitchType;

    //������ ���� ���� �Ѱ��ֱ�
    public void OnClickBallChoiceBtn()
    {
        ballUI.SelectPitchType(pitchType);          
    }
}
