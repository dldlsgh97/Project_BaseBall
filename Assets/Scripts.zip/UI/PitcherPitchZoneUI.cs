using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PitcherPitchZoneUI : UIBase
{
    [SerializeField] //ź���� ǥ�� UI(���� ����)
    private RectTransform TargetUI;
    [SerializeField] //�� ������ ���� UI(���� ����)
    private RectTransform PitchZone;
    [SerializeField] //ź���� ǥ�� UI(WorldUI)
    private RectTransform WorldTargetUI;
    [SerializeField] //����UIĵ����
    private Canvas UICanvas;
   
    //TestObj ���� ��ġ�� => ź����
    private Vector3 WorldTargetPos;

    [SerializeField]
    private TextMeshProUGUI PitchTypeText;

    [SerializeField]
    private GameObject TestObj;

    public override void OnOpened(object[] param)
    {
        if(param != null && param.Length > 0)
        {
            PitchType type = (PitchType)param[0];
            SetPitchTypeText(type);
        }        
    }
    public event Action<Vector3> OnPitchZoneSelected;
    
    void SetPitchTypeText(PitchType type)
    {
        switch (type)
        {
            case PitchType.FastBall:
                PitchTypeText.text = "����";
                break;
            case PitchType.CurveBall:
                PitchTypeText.text = "Ŀ��";
                break;
            case PitchType.SliderBall:
                PitchTypeText.text = "�����̴�";
                break;
        }
    }
    void Update()
    {
        Vector2 localMousePos;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            PitchZone, Input.mousePosition, UICanvas.worldCamera, out localMousePos);

        if (PitchZone.rect.Contains(localMousePos))
        {
            TargetUI.gameObject.SetActive(true);
            
            TargetUI.localPosition = localMousePos;
            WorldTargetUI.localPosition = TargetUI.localPosition;
            WorldTargetPos = WorldTargetUI.position;
            TestObj.transform.position = WorldTargetPos;
            
            if (Input.GetMouseButtonDown(0))//Ŀ���� ������ Ŭ���� Ȯ��
            {
                OnPitchZoneSelected?.Invoke(WorldTargetPos);
                //onComplete?.Invoke(true); //�ݹ����� ��� ����
                //State = PitchState.SetAccuracy;
            }
        }
    }
}
