using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class BallChoiceUI : UIBase
{
    //�������� �̺�Ʈ
    public Action<PitchType> OnPitchTypeSelected;

    public override void OnOpened(object[] param)
    {
        Debug.Log("BallChoiceUI Open");
    }

    public override void OnClosed(object[] param)
    {
        Debug.Log("BallChoiceUI Close");
    }

    public void SelectPitchType(PitchType type)
    {
        OnPitchTypeSelected?.Invoke(type);
    }
}
