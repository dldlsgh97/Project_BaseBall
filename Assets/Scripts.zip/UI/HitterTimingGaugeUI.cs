using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitterTimingGaugeUI : UIBase
{
    [SerializeField]
    private RectTransform cursor;
    [SerializeField]
    private GameObject gauge;
    private RectTransform rt;
    private float gaugeWidth = 0;
    private float gaugeLeftEdge = 0;
    private float gaugeRightEdge = 0;
    private float cursorWidth = 0;

    private float ballTimer = 0; //���� �������� ź������ �����ϴ� ��ü �ð�
    private float timingRatio = 0; //Ÿ�ڰ� ��Ʈ�� �ֵθ��� Ÿ�̹�/��ü�ð� ����
    [SerializeField]
    private float cursorSpeed = 0;

    private Vector2 cursorStartPos;
    private Vector2 cursorEndPos;

    private bool isInitHitterTiming = false;

    private Coroutine timerCoroutine;

    //Ÿ�� ����Ÿ�̹� ��� �Ѱ��ֱ�� �̺�Ʈ
    public Action<float> OnTimingFinished;
    public override void OnOpened(object[] param)
    {
        rt = gauge.GetComponent<RectTransform>();
        gaugeWidth = rt.sizeDelta.x;
        float gaugeCenter = rt.anchoredPosition.x;
        gaugeLeftEdge = gaugeCenter - (gaugeWidth / 2);
        gaugeRightEdge = gaugeCenter + (gaugeWidth / 2);
        cursorWidth = cursor.sizeDelta.x;

        //���� ���� ����
        ballTimer = (float)param[0];
        StartHittingTimer();
    }

    public void StartHittingTimer()
    {
        if (!isInitHitterTiming)
        {
            InitCursor();
            isInitHitterTiming = true;
        }
        timerCoroutine = StartCoroutine(MoveCursor());
    }
    void InitCursor() //���� �ʱ�ȭ
    {
        // Ŀ����ġ �ʱ�ȭ
        float posX = gaugeLeftEdge + (cursorWidth / 2);
        float endPosX = gaugeRightEdge - (cursorWidth / 2);
        cursorStartPos = new Vector2(posX, cursor.anchoredPosition.y);
        cursorEndPos = new Vector2(endPosX, cursor.anchoredPosition.y);
        cursor.anchoredPosition = cursorStartPos;
    }

    IEnumerator MoveCursor() //Ŀ���� �����̴� �ڷ�ƾ
    {
        float elapsed = 0f;
        while (elapsed < ballTimer)
        {
            elapsed += Time.deltaTime;
            float time = elapsed / ballTimer;
            Vector2 pos = Vector2.Lerp(cursorStartPos, cursorEndPos, time);
            cursor.anchoredPosition = pos;
            yield return null;
        }        
    }

    IEnumerator HitterTimingResult()
    {
        isInitHitterTiming = false;
        float cursorX = cursor.anchoredPosition.x;
        timingRatio = (cursorX - gaugeLeftEdge) / gaugeWidth;
        //Ÿ�� ����Ÿ�̹� ��� �Ѱ��ֱ�� �̺�Ʈ
        OnTimingFinished?.Invoke(timingRatio);
        yield return null;
    }

    //Ÿ�ݹ�ư Ŭ���� �ڷ�ƾ ����
    public void StopHitterCoroutine()
    {
        StartCoroutine(HitterTimingResult());
        StopCoroutine(timerCoroutine);
    }
}
