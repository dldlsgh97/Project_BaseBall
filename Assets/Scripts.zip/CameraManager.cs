using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraManager: MonoBehaviour
{
    // ���� audioListener �� ī�޶� ���� Ȱ��ȭ �� ��Ȱ��ȭ �ʿ�
    [SerializeField]
    private List<Camera> cameras;

    private CameraMod gameMod;
    private void OnEnable()
    {
        //ī�޶� ���� �̺�Ʈ ����
        CameraEvents.OnCameraRequest += SetCamera;
    }
    private void OnDisable()
    {
        //ī�޶� ���� �̺�Ʈ ����
        CameraEvents.OnCameraRequest -= SetCamera;
    }
    public void SetCamera(CameraMod mod)
    {
        foreach (Camera cam in cameras)
        {
            if (cam.name == mod.ToString())
            {
                cam.gameObject.SetActive(true);
                cam.enabled = true;
            }
            else
            {
                cam.enabled = false;
                cam.gameObject.SetActive(false);
            }
        }
    }
}
