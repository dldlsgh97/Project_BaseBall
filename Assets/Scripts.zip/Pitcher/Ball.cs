using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    [Header("ź���� ��ġ��")]
    [SerializeField]
    private Transform StartPosition;
    [SerializeField]
    private Transform TargetPosition; //��Ȯ�� �������� ź����

    [Header("ź���� ��ġ ������Ʈ")]
    [SerializeField]
    private Transform targetPoint; //��Ȯ�� ��������� ź����
    [SerializeField]
    public GameObject Offset_Target;

    [Header("Ŀ�� ���� ����")]
    [SerializeField]
    private Vector3 midPosition;

    private float elapsed;

    private float curveDuration = 1.0f; //���� ���� (��ġ�� �۾������� �����ð��� ������)
    public float curveAmount = 2.0f;

    [Header("�̺�Ʈ")]
    //ź���� ���� Ʈ���� �̺�Ʈ
    public Action OnBallToTarget;

    //Ÿ�� Ÿ�̸� ��ŸƮ Ʈ���� �̺�Ʈ(���� �ð��� ���� �ѱ�)
    public Action<float> OnStartHittingTimer;
    
    private void OnEnable()
    {
        gameObject.transform.position = StartPosition.position;
    }

    public void ThrowBall(PitchType type, float accuracy,Vector3? targetPos = null)
    {
        if (targetPos.HasValue)
        {
            TargetPosition.transform.position = targetPos.Value;
        }
        SetTargetPosition(accuracy);
        // ���⼭ �Ѱ��������� Flow�ʿ��� �Ѱ��ֱ�
        Debug.Log("Ball" + curveDuration);
        switch (type)
        {
            case PitchType.FastBall:
                OnStartHittingTimer?.Invoke(curveDuration);
                StartCoroutine(FastBall());
                break;
            case PitchType.CurveBall:
                OnStartHittingTimer?.Invoke(curveDuration);
                StartCoroutine(CurveBall());
                break;
            case PitchType.SliderBall:
                OnStartHittingTimer?.Invoke(curveDuration);
                StartCoroutine(SliderBall());
                break;
        }
    }

    void SetTargetPosition(float accuracy)
    {
        targetPoint.transform.position = TargetPosition.position;
        float horizontalOffset = UnityEngine.Random.Range(0, accuracy); //���� ���� ������
        float verticalOffset = UnityEngine.Random.Range(0, accuracy); //���� ���� ������
        
        float signX = 1; //���ο��� +- ��ȣ
        float signY = 1; //���ο��� +- ��ȣ

        if(UnityEngine.Random.value < 0.5f) signX = -1;
        if (UnityEngine.Random.value < 0.5f) signY = -1;
        Vector3 start = StartPosition.position;
        Vector3 end = TargetPosition.position;

        Vector3 right = Vector3.Cross(Vector3.up, end - start).normalized;

        Vector3 offSet = (right * horizontalOffset * signX) + (Vector3.up * verticalOffset * signY);

        targetPoint.position += offSet;
        Offset_Target.SetActive(true);
        Offset_Target.transform.position = targetPoint.position;
    }
    IEnumerator FastBall()
    {
        #region ���� ���� ����
        /*Vector3 target = targetPoint.position;
        while (Vector3.Distance(gameObject.transform.position , target) > 0.05f)
        {
            gameObject.transform.position = Vector3.MoveTowards(gameObject.transform.position, target, ballSpeed * Time.deltaTime);
            yield return null;
        }
        gameObject.transform.position = StartPosition.position;*/
        #endregion
        #region ���� ���� (Ŀ��, �����̴��� ���� �ð��� �����ϴ� ����)
        Vector3 target = targetPoint.position;
        Vector3 start = StartPosition.position;

        elapsed = 0;
        while(elapsed < curveDuration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / curveDuration;
            Vector3 pos = Vector3.Lerp(start, target, t);
            transform.position = pos;
            yield return null;
        }
        #endregion
        transform.position = StartPosition.position;
        //���� Ʈ���� �̺�Ʈ
        OnBallToTarget?.Invoke();
    }

    IEnumerator CurveBall()
    {
        Vector3 start = StartPosition.position;
        Vector3 end = targetPoint.position;       
        Vector3 mid = (start + end) * 0.5f;

        Vector3 right = Vector3.Cross(Vector3.up, end - start).normalized;

        Vector3 apex = mid + right * curveAmount;

        elapsed = 0f;

        while (elapsed < curveDuration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / curveDuration;

            Vector3 p1 = Vector3.Lerp(start, apex, t);
            Vector3 p2 = Vector3.Lerp(apex, end, t);
            Vector3 curvePos = Vector3.Lerp(p1, p2, t);

            transform.position = curvePos;

            yield return null;
        }

        transform.position = StartPosition.position;
        //���� Ʈ���� �̺�Ʈ
        OnBallToTarget?.Invoke();
    }
    IEnumerator SliderBall()
    {
        Vector3 start = StartPosition.position;
        Vector3 end = targetPoint.position;
        Vector3 mid = (start + end) * 0.5f;

        Vector3 right = Vector3.Cross(Vector3.up, end - start).normalized;

        Vector3 apex = mid - right * curveAmount;

        elapsed = 0f;

        while (elapsed < curveDuration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / curveDuration;

            Vector3 p1 = Vector3.Lerp(start, apex, t);
            Vector3 p2 = Vector3.Lerp(apex, end, t);
            Vector3 curvePos = Vector3.Lerp(p1, p2, t);

            transform.position = curvePos;

            yield return null;
        }

        transform.position = StartPosition.position;
        //���� Ʈ���� �̺�Ʈ
        OnBallToTarget?.Invoke();
    }
}
