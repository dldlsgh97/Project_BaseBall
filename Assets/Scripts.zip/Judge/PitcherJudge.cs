using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PitcherJudge : MonoBehaviour
{

    public void JudgeStrike()
    {
        
    }
}
