using System.Collections;
using System;
using System.Collections.Generic;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    [SerializeField]
    private Dictionary<Type, UIBase> uiDict = new();

    [SerializeField] //�ʱ� ��Ȱ��ȭ �Ǿ��ִ� UI��Ͽ� ����Ʈ
    private List<UIBase> uiList;
    private void Awake()
    {
        Instance = this;

        //UI ������� ó��
        foreach(var ui in uiList)
        {
            ReisterUI(ui);
        }
    }
    public void ReisterUI(UIBase ui) //UI ���
    {
        var type = ui.GetType();
        if (!uiDict.ContainsKey(type))
        {
            uiDict.Add(type, ui);
            //Debug.Log($"{type}.type {ui}.ui ��ϵ� UI����{uiDict.Count}");
        }
        else
        {
            Debug.Log($"Reister{type} UI �� ��ϵǾ� �ֽ��ϴ�");
        }
    }

    public T Get<T>() where T : UIBase //UI ������
    {
        var type = typeof(T);
        if (uiDict.TryGetValue(type, out var ui))
        {
            return (T)ui;
        }

        Debug.Log($"[UIManager] {type} UI�� ��ϵ��� �ʾҽ��ϴ�");
        return null;
    }
    public void Show<T>(params object[] param) where T : UIBase //UI ����
    {
        var ui = Get<T>();
        if(ui == null)
        {
            Debug.LogError($"[UIManager] {typeof(T)} UI�� null�Դϴ�.");
            return;
        }
        ui.SetActive(true);
        ui.opened?.Invoke(param);

    }
    public void Hide<T>(params object[] param) where T : UIBase //UI �ݱ�
    {
        var ui = Get<T>();
        if (ui == null)
        {
            return;
        }
        ui.SetActive(false);
        ui.closed?.Invoke(param);
    }
}
